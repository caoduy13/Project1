﻿namespace Snake
{
    public class DirectionBase
    {
        public int ColOffset { get; }

        public int RowOffset { get; }
    }
}