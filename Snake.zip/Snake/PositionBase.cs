﻿namespace Snake
{
    internal class PositionBase
    {
        public int Col { get; }
        public int Row { get; }
    }
}